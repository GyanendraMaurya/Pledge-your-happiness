<?php
$con = mysqli_connect("localhost","root","*@cCjesusTr") or die("Unable to connect");	
mysqli_select_db($con,'Pledge_your_happiness'); 
	
?>
