<?php
	require 'dbconfig/config.php';
?>
<!DOCTYPE>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale =1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Site for finding...">
    <meta name="author" content="droppers">
    <meta name="keywords" content="">

    <title>Pledge your happiness </title>
    <link rel="icon" href="images/abc.jpg">
    <link rel="stylesheet" href="css/style2.css">
    <link rel="stylesheet" href="css/materialize.min.css">
    
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<!--<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.0/css/materialize.min.css">

</head>

<body>

<nav>
    <div class="nav-wrapper">
      
      <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
      <ul class="right hide-on-med-and-down">
        <li><a href="index.html">Home</a></li>
            <li><a href="helpline.html">Helpline</a></li>
            <li><a href="donation_form.php">Donation</a></li>
            <li><a href="about.html">About Us</a></li>
            <li><a href="contact.php">Contact</a></li>
      </ul>
      <ul class="side-nav" id="mobile-demo">
        <li><a href="index.html">Home</a></li>
            <li><a href="helpline.html">Helpline</a></li>
            <li><a href="donation_form.html">Donation</a></li>
            <li><a href="about.html">About Us</a></li>
            <li><a href="contact.php">Contact</a></li>
      </ul>
    </div>
  </nav>

    <!--<nav id="navbar">
        <div class='myicon'><!--<i class="fa fa-bars" aria-hidden="true"></i> 
        <i class="material-icons" >reorder</i>
        </div>
        <ul class="ulist">
            <li><a href="index.html">Home</a></li>
            <li><a href="helpline.html">Helpline</a></li>
            <li><a href="donation_form.html">Donation</a></li>
            <li><a href="about.html">About Us</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
    </nav>
-->
    <div id="wrapper">
        <header>
            <h1>Company </h1>
            <small>This is fr a tagline</small>
        </header>
        <div id="space"><br></div>
        <div id="main">
			<div class="container">
	
	
		<div id="header1">
			<p id="heading">FORM</p>
		</div>
		<form action="donation_form.php" method = "post" name="donation">
			<div class ="subcontainer">
        <div class="input-field col s12">
            <select class="icons ">
                <option value="" disabled selected>Choose your title</option>
                <option value="" data-icon="images/mr.png" class="left circle">Mr</option>
                <option value="" data-icon="images/mrs.png" class="left circle">Mrs</option>
                <option value="" data-icon="images/dr.png" class="left circle">Dr</option>
            </select>
            <label for="icon_prefix"></label>
        </div>
        <div class="input-field col s12">
            <i class="material-icons prefix">account_circle</i>
            <input id="icon_prefix" type="text" class="validate" name="fname">
            <label for="icon_prefix">First Name</label>
        </div>
        <div class="input-field col s12">
            <i class="material-icons prefix">account_circle</i>
            <input id="icon_prefix" type="text" class="validate" name="mname">
            <label for="icon_prefix">Middle Name</label>
        </div>
        <div class="input-field col s12">
            <i class="material-icons prefix">account_circle</i>
            <input id="icon_prefix" type="text" class="validate" name="lname">
            <label for="icon_prefix">Last Name</label>
        </div>
        <div class="input-field col s12">
            <i class="material-icons prefix">account_circle</i>
            <input id="icon_prefix" type="text" class="validate" name="uname">
            <label for="icon_prefix">UserName</label>
        </div>
        <div class="input-field col s12">
            <i class="material-icons prefix">place</i>
            <input id="icon_prefix" type="text" class="validate" name="pcode">
            <label for="icon_prefix">Postal Code</label>
        </div>
        <div class="input-field col s12">
            <i class="material-icons prefix">message</i>
            <input id="icon_prefix" type="text" class="validate" name="add1">
            <label for="icon_prefix">Address Line 1</label>
        </div>
        <div class="input-field col s12">
            <i class="material-icons prefix">message</i>
            <input id="icon_prefix" type="text" class="validate" name="add2">
            <label for="icon_prefix">Address Line 2</label>
        </div>
        <div class="input-field col s12">
            <i class="material-icons prefix">my_location</i>
            <input id="icon_prefix" type="text" class="validate" name="location">
            <label for="icon_prefix">Town</label>
        </div>
        <div class="input-field col s12">
            <i class="material-icons prefix">satellite</i>
            <input id="icon_prefix" type="text" class="validate" name="country">
            <label for="icon_prefix">Country</label>
        </div>
        <div id="donation">
            <label for="donation" style="font-size:15px"> Select organs</label>
            <div class="row">
                <div class="col s6 l3">
                    <p>
                        <input type="checkbox" id="test1" />
                        <label for="test1">Kidney</label>
                    </p>
                </div>
                <div class="col s6 l3">
                    <p>
                        <input type="checkbox" id="test2" />
                        <label for="test2">Heart</label>
                    </p>
                </div>
                <div class="col s6 l3">
                    <p>
                        <input type="checkbox" id="test3" />
                        <label for="test3">Liver</label>
                    </p>
                </div>
                <div class="col s6 l3">
                    <p>
                        <input type="checkbox" id="test4" />
                        <label for="test4">Lungs</label>
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col s6 l3">
                    <p>
                        <input type="checkbox" id="test5" />
                        <label for="test5">Small Bowels</label>
                    </p>
                </div>
                <div class="col s6 l3">
                    <p>
                        <input type="checkbox" id="test6" />
                        <label for="test6">Corneas</label>
                    </p>
                </div>
                <div class="col s6 l3">
                    <p>
                        <input type="checkbox" id="test7" />
                        <label for="test7">Pancreas</label>
                    </p>
                </div>
			
                <div class="col s6 l3">
                    <p>
                        <input type="checkbox" id="test8" />
                        <label for="test8">Tissues</label>
                    </p>
                </div>
			</div>
				<div class="row">
				<div class="col s6 l3">
                    <p>
                        <input type="checkbox" id="test9" />
                        <label for="test9">Eye</label>
                    </p>
                </div>
				<div class="col s6 l3">
                    <p>
                        <input type="checkbox" id="test10" />
                        <label for="test10">Intestine</label>
                    </p>
                </div>
				<div class="col s6 l3">
                    <p>
                        <input type="checkbox" id="test11" />
                        <label for="test11">Bone Marrow</label>
                    </p>
                </div>
				<div class="col s6 l3">
                    <p>
                        <input type="checkbox" id="test12" />
                        <label for="test12">Skin</label>
                    </p>
                </div>
				</div>
            
        </div>
			
        <div id="gender">
            <label for="gender" style="font-size:15px"> Select Gender</label>
            <div class="row">
                <div class="col s6 l3">
                    <p>
                        <input class="with-gap" name="gender" type="radio" id="male" />
                        <label for="male">Male</label>
                    </p>
                </div>
                <div class="col s6 l3">
                    <p>
                        <input class="with-gap" name="gender" type="radio" id="female" />
                        <label for="female">Female</label>
                    </p>
                </div>
                <div class="col s6 l3">
                    <p>
                        <input class="with-gap" name="gender" type="radio" id="other" />
                        <label for="other">Other</label>
                    </p>
                </div>
                <div class="col s6 l3">
                    <p>
                        <input class="with-gap" name="gender" type="radio" id="rns" />
                        <label for="rns">Rather not say</label>
                    </p>
                </div>
            </div>
        </div>
        <div>
            <i class="material-icons prefix">date_range</i>
            <label for="icon_prefix" style="font-size:15px">Date Of Birth</label>
            <input id="icon_prefix" type="date" class="datepicker" name="dob">
        </div>
        <div>
            <div class="input-field col s12">
            <select class="icons ">
                <option value=""  data-icon="images/religion.png" class="left circle"disabled selected>Choose your religion</option>
                <option value="" data-icon="" class="left circle">&emsp; &emsp;&nbsp; &nbsp;No Religion</option>
				<option value="" data-icon="images/buddhist.jpg" class="left circle">Buddhist</option>
                <option value="" data-icon="images/christian.png" class="left circle">Christian</option>
                <option value="" data-icon="images/hindu.png" class="left circle">Hindu</option>
                <option value="" data-icon="images/jewish.png" class="left circle">Jewish</option>
                <option value="" data-icon="images/muslim.jpg" class="left circle">Muslim</option>
                <option value="" data-icon="images/sikh.png" class="left circle">Sikh</option>
            </select>
        </div>
        </div>
        <div class="input-field col s12">
            <i class="material-icons prefix">email</i>
            <input id="icon_prefix" type="email" class="email" name="email">
            <label for="icon_prefix">Email</label>
        </div>
        <div class="input-field col s12">
            <i class="material-icons prefix">phone</i>
            <input id="icon_telephone" type="tel" class="validate" name="telno">
            <label for="icon_telephone">Telephone</label>
        </div>
        <div>
            <button class="btn waves-effect waves-light" type="submit" name="submit">Submit
                <i class="material-icons right">send</i>
            </button>
        </div>
        
    </div>
	</div></form>
		
</div>
        
        <footer>
            <p>Copyright &copy;</p>
        </footer>
    </div>


		<?php
		$id = 000000000000000;
				if(isset($_POST['submit']))
				{
						//echo '<script type="text/javascript"> alert("Hello");</script>';
						$firstname = $_POST['fname'];
						$middlename = $_POST['mname'];
						$lastname = $_POST['lname'];
						$username = $_POST['uname'];
						$pcode = $_POST['pcode'];
						$add1 = $_POST['add1'];
						$add2 = $_POST['add2'];
						$town = $_POST['location'];
						$country = $_POST['country'];
						$dob = $_POST['dob'];
						$gender = $_POST['gender'];
						$email = $_POST['email'];
						$contact = $_POST['telno'];
						
							$query = "select * from donors where username = '$username' ";
							$query_run = mysqli_query($con,$query);
							if(mysqli_num_rows($query_run)>0)
							{
								echo '<script type="text/javascript"> alert("Username already exists try another username");</script>';
							}
							else
							{
								$id++; 
									$query = "insert into donors (firstname,middlename,lastname,username,postalcode,Addressline1, Addressline2, town, country,gender,DOB, Email,contactno,uid) values('$firstname','$middlename','$lastname','$username','$pcode','$add1','$add2','$town','$country','$gender','$email','$contact','$uid')";
									$query_run = mysqli_query($con,$query);
									
									if($query_run)
									{
										echo '<script type="text/javascript"> alert("User registered");</script>';
									}
									else
									{
										echo '<script type="text/javascript"> alert("Error occurred");</script>';
									}
							}				
				}
       ?>

    <!--Import jQuery before materialize.js-->
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script type="text/javascript" src="js/materialize.min.js"></script>
    <script>
        $(document).ready(function () {
            $('select').material_select();
            $(".button-collapse").sideNav();
        });
         $('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15 // Creates a dropdown of 15 years to control year
  });
    </script>
<script src="js/script.js"></script>
</body>

</html>
